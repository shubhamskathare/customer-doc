package com.ltimindtree;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.ltimindtree.controller.CustomerController;
import com.ltimindtree.entity.Customer;
import com.ltimindtree.exception.CustomerNotFoundException;
import com.ltimindtree.service.impl.CustomerServiceImpl;




@TestMethodOrder(OrderAnnotation.class)
@SpringBootTest(classes= {ControllerMockitoTest.class})
public class ControllerMockitoTest {
	
	@Mock
	private CustomerServiceImpl customerService;
	
	@InjectMocks
	private CustomerController customerController;
	
	
	
	@Test
	@Order(1)
	public void test_addCustomer() {
	 Customer customer=new Customer(1, "John", "josh@gmail.com", "2vaf", "2345");
		when(customerService.saveCustomer(customer)).thenReturn(customer);
		ResponseEntity<Customer> res=customerController.addCustomer(customer);
		
		assertEquals(HttpStatus.CREATED, res.getStatusCode());
		assertEquals(customer, res.getBody());
	}
	
	@Test
	@Order(2)
	public void test_updateCountry() throws CustomerNotFoundException {
		Customer customer=new Customer(1, "John", "john@gmail.com", "2vaf", "2345");
		int id=1;
		
		
		when(customerService.getCustomerById(id)).thenReturn(customer);   //mocked two external dependenciency
		
		when(customerService.updateCustomer(customer, id)).thenReturn(customer);
		ResponseEntity<Customer> res=customerController.updateCustomer(customer, id);
		assertEquals(HttpStatus.OK, res.getStatusCode());
		assertEquals(1, res.getBody().getId());
		assertEquals("John", res.getBody().getCustomerName());
		assertEquals("john@gmail.com", res.getBody().getEmail());
		assertEquals("2vaf", res.getBody().getPassword());
		assertEquals("2345", res.getBody().getCustomerCellNo());
		
	}
	
	@Test
	@Order(3)
	public void test_deleteCountry() throws CustomerNotFoundException {
		Customer customer=new Customer(1, "John", "josh@gmail.com", "2vaf", "2345");
		int id=1;
		when(customerService.getCustomerById(id)).thenReturn(customer);
		ResponseEntity<String> res=customerController.deactivateCustomer(id);
		assertEquals(HttpStatus.OK, res.getStatusCode());
		
	}


}

package com.ltimindtree.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltimindtree.entity.Customer;
import com.ltimindtree.exception.CustomerNotFoundException;
import com.ltimindtree.service.impl.CustomerServiceImpl;

@RestController
@RequestMapping("/customers")
public class CustomerController {
	
	@Autowired
	private CustomerServiceImpl customerImpl;
	
	
	
	//localhost:8080/customers/addcustomer
	@PostMapping("/addcustomer")
		public ResponseEntity<Customer> addCustomer(@RequestBody Customer customer) {
			
			try {
				customer= customerImpl.saveCustomer(customer);
				return new ResponseEntity<Customer>(customer,HttpStatus.CREATED);
			} catch (Exception e) {
				return new ResponseEntity<>(HttpStatus.CONFLICT);
			}
		}
	
	//localhost:8080/customers/customerUpdate/{id}
	@PutMapping("/customerUpdate/{id}")
	public ResponseEntity<Customer> updateCustomer(@RequestBody Customer customer, @PathVariable(value = "id") int id) throws CustomerNotFoundException{
		Customer updateCustomer=customerImpl.updateCustomer(customer, id);
		if(updateCustomer==null) {
			return new ResponseEntity<Customer>(HttpStatus.INTERNAL_SERVER_ERROR);  
		}
		return new ResponseEntity<Customer>(updateCustomer, HttpStatus.OK);
	}
	
	//localhost:8080/customers/
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deactivateCustomer(@PathVariable int id) throws CustomerNotFoundException{
		customerImpl.deleteCustomer(id);
		return new ResponseEntity<String>("Customer Deleted Successfully",HttpStatus.OK);
	}
	
	@GetMapping("/getcustomers/{id}")
	public ResponseEntity<Customer> getCustomerById(@PathVariable(value="id") int id) {
		try {
			Customer customer=customerImpl.getCustomerById(id);
			return new ResponseEntity<Customer>(customer,HttpStatus.FOUND);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

}

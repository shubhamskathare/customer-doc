package com.ltimindtree.service;

import com.ltimindtree.entity.Customer;
import com.ltimindtree.exception.CustomerNotFoundException;

public interface CustomerService {
	
	public Customer getCustomerById(int id);
	public Customer saveCustomer(Customer customer);
	public Customer updateCustomer(Customer customer, int id) throws CustomerNotFoundException;
	public void deleteCustomer(int id) throws CustomerNotFoundException;

}
